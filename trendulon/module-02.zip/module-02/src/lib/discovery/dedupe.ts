import type { RawDiscoveredStory } from './gemini-client';

/**
 * Judgment call, flagged (per brief): dedup is done here as a discrete
 * post-processing step, NOT inside the Gemini prompt.
 *
 * Why: asking the model to dedupe/group in the same call makes correctness
 * un-testable — you'd be trusting a second, unverifiable AI judgment call
 * for something that needs a deterministic Jest test. Doing it here means
 * the grouping logic is plain code you can unit-test against fixtures
 * (see __tests__/discovery.test.ts), and it keeps Discovery's job to
 * "search," not "make editorial groupings" — that reads closer to the
 * module-boundary spirit in the Constitution even though dedup isn't
 * explicitly a Module 03/04 concern.
 *
 * Method: two stories merge if they (a) share enough significant words in
 * the headline (Jaccard similarity over a stopword-stripped token set) AND
 * (b) their event_time (if both known) falls within a 36-hour window.
 * Two unrelated same-day earthquakes will usually NOT share enough headline
 * vocabulary to cross the threshold — see the "distinct events" test case.
 */

const STOPWORDS = new Set([
  'a', 'an', 'the', 'in', 'on', 'at', 'of', 'to', 'for', 'and', 'or', 'is',
  'are', 'was', 'were', 'after', 'over', 'amid', 'as', 'with', 'from', 'by',
  'its', 'has', 'have', 'had', 'it', 'this', 'that', 'new', 'says', 'said',
]);

const SIMILARITY_THRESHOLD = 0.5;
const TIME_WINDOW_MS = 36 * 60 * 60 * 1000;

export interface DedupedStory extends RawDiscoveredStory {
  merged_from_count: number;
}

export function dedupeStories(raw: RawDiscoveredStory[]): DedupedStory[] {
  const groups: DedupedStory[] = [];

  for (const story of raw) {
    const match = groups.find((g) => sameEvent(g, story));
    if (match) {
      mergeInto(match, story);
    } else {
      groups.push({ ...story, source_urls: [...story.source_urls], merged_from_count: 1 });
    }
  }

  return groups;
}

function sameEvent(a: RawDiscoveredStory, b: RawDiscoveredStory): boolean {
  const sim = headlineSimilarity(a.headline, b.headline);
  if (sim < SIMILARITY_THRESHOLD) return false;

  if (a.event_time && b.event_time) {
    const dt = Math.abs(new Date(a.event_time).getTime() - new Date(b.event_time).getTime());
    if (dt > TIME_WINDOW_MS) return false;
  }

  return true;
}

function mergeInto(target: DedupedStory, addition: RawDiscoveredStory): void {
  for (const url of addition.source_urls) {
    if (!target.source_urls.includes(url)) target.source_urls.push(url);
  }
  // Prefer the longer, presumably more detailed summary.
  if (addition.summary.length > target.summary.length) target.summary = addition.summary;
  if (!target.event_time && addition.event_time) target.event_time = addition.event_time;
  if (!target.category && addition.category) target.category = addition.category;
  target.merged_from_count += 1;
}

function headlineSimilarity(a: string, b: string): number {
  const tokensA = tokenize(a);
  const tokensB = tokenize(b);
  if (tokensA.size === 0 || tokensB.size === 0) return 0;

  let intersection = 0;
  for (const t of tokensA) if (tokensB.has(t)) intersection++;
  const union = tokensA.size + tokensB.size - intersection;
  return union === 0 ? 0 : intersection / union;
}

function tokenize(headline: string): Set<string> {
  return new Set(
    headline
      .toLowerCase()
      .replace(/[^a-z0-9\s]/g, ' ')
      .split(/\s+/)
      .filter((w) => w.length > 2 && !STOPWORDS.has(w))
  );
}

/** Builds the unique key used to avoid re-inserting a story on a repeat scan. */
export function buildDedupeKey(story: RawDiscoveredStory | DedupedStory): string {
  const dateWindow = story.event_time
    ? story.event_time.slice(0, 10) // YYYY-MM-DD
    : new Date().toISOString().slice(0, 10);

  const normalizedHeadline = Array.from(tokenize(story.headline)).sort().join('-');
  return `${dateWindow}:${normalizedHeadline}`;
}
