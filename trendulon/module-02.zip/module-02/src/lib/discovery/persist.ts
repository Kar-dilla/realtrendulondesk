import type { PrismaClient } from '@prisma/client';
import { buildDedupeKey, type DedupedStory } from './dedupe';

export interface PersistResult {
  inserted: number;
  skipped_existing: number;
}

/**
 * Upserts on dedupe_key: if a scan re-discovers something already stored
 * today, we don't insert a duplicate row. We deliberately don't touch
 * verification_tier / fit_score on conflict — those belong to later
 * modules and Module 02 must never overwrite them once set.
 */
export async function persistStories(prisma: PrismaClient, stories: DedupedStory[]): Promise<PersistResult> {
  let inserted = 0;
  let skipped_existing = 0;

  for (const story of stories) {
    const dedupe_key = buildDedupeKey(story);

    const existing = await prisma.story.findUnique({ where: { dedupe_key } });
    if (existing) {
      skipped_existing++;
      continue;
    }

    await prisma.story.create({
      data: {
        headline: story.headline,
        summary: story.summary,
        category: story.category,
        source_urls: story.source_urls,
        event_time: story.event_time ? new Date(story.event_time) : null,
        dedupe_key,
        // verification_tier and fit_score left unset — Module 03/04's job.
      },
    });
    inserted++;
  }

  return { inserted, skipped_existing };
}
