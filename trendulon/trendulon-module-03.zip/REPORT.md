# Module 03 — Verification: Handoff Report

## Files, by purpose

- `prisma/schema.prisma` — full updated file. Added `VerifiedClaim` model + the
  inverse `verifiedClaims` relation on `Story`. Mapped to `verified_claims`
  (snake_case) to match the existing `stories` convention, and indexed on
  `storyId` since every query pattern here is "claims for this story."
- `lib/verification/classify.ts` — the Groq call. **Inline fetch, not a shared
  client** — I kept it consistent with Module 02's existing pattern (each
  module makes its own call) rather than extracting `lib/groq-client.ts`,
  since you said match-existing was the safer default and there's no shared
  client yet for a third module to also depend on. Flagging in case you'd
  rather extract one now that it's the second occurrence.
- `lib/verification/rollup.ts` — pure function, most-conservative-tier logic.
  Kept separate from `classify.ts` so it's trivial to unit test in isolation.
- `app/api/verification/run/route.ts` — `POST` runs the batch, `GET` returns
  the pending count (needed by the dashboard's button; the brief allowed this
  only "if cheap" — a `count()` on an indexed/small table is).
- `app/verification/page.tsx` — the dashboard.
- `components/VerificationBadge.tsx` — shared tier badge, used by both the
  verification page and (see below) intended for Discovery.

## Groq-vs-Claude divergence (per the Constitution, section 5)

Per the brief: Groq stays the default for this module (`openai/gpt-oss-120b`)
until you have budget for the Anthropic API, even though the Constitution's
stated intent was Claude for verification-tier classification specifically.
This is the same tradeoff already made in Module 02 — noted here as
instructed, not silently absorbed.

## Never-fabricate-a-tier, made concrete

- Any single malformed claim (bad/missing tier, empty claim text) rejects the
  **whole** model response for that story as `malformed_response` — not a
  partial accept. A model that got 3 of 4 claims right but hallucinated a
  tier on the 4th is not a model you can trust for the other 3 either.
- `left_null` is broken into three buckets that mean different things:
  - `model_failure` — the Groq call itself failed or came back unusable
    (rate limit, missing key, timeout, malformed JSON).
  - `unclassifiable_content` — Groq responded fine and explicitly found no
    extractable claims (thin/headline-only content).
  - `db_write_failed` — classification succeeded but the transaction to
    persist it didn't. Rare, but "classified correctly, never saved" is a
    different failure than "couldn't classify," and reporting them the same
    way would hide a real bug.

## ⚠️ Discovery page badge — needs one thing from you before I wire it in

The brief's Discovery-page shape you gave me is:
`{ headline, summary, category, source_urls, event_time, merged_from_count }`
— this matches the **scan response** shape (`persistStories`/`dedupeStories`
output), not a Prisma `Story` read. It has no `verification_tier` field.

If Discovery's page only ever renders that ephemeral scan-response array (not
a fresh DB read), then there's currently nothing for a badge to key off of on
that page — a story only gets a `verificationTier` *after* Module 03 runs,
which happens after the scan response has already been rendered and
discarded. Wiring `<VerificationBadge>` in against a field that isn't there
would silently render "Not yet verified" on everything, forever, even after
you *have* verified a story — which is worse than not having the badge at
all, since it'd look correct while being wrong.

Rather than guess, I built `VerificationBadge` as a standalone component
ready to drop in, and left the actual Discovery page untouched. To finish
this small piece, tell me either:
1. Discovery's page does a fresh Prisma/API read of stories (in which case:
   does that read return `verificationTier` or `verification_tier`?), or
2. paste the actual `app/discovery/page.tsx`, and I'll wire the badge in
   directly, matching its existing map/render structure exactly.

Everything else in this brief (data model, endpoint, dashboard, tests) does
not depend on this and is complete as delivered.

## Test framework: assumed Vitest

No test config was provided, so I wrote these against **Vitest**
(`describe`/`it`/`vi.mock`/`vi.hoisted`) plus
`@testing-library/react` for the badge component test. If Module 02's tests
actually run on Jest, the fixes needed are small and mechanical:
`vi.fn()` → `jest.fn()`, `vi.mock`/`vi.hoisted` → `jest.mock` (Jest auto-hoists
`jest.mock` calls, so the `vi.hoisted` wrapper can just be inlined), and
`vi.clearAllMocks()` → `jest.clearAllMocks()`. Let me know which you're on
and I'll convert them if needed — I did not want to guess and hand you tests
that fail for tooling reasons rather than real ones.

## What I could not do in this environment

- **Could not run these tests.** This sandbox has no network access, so
  there's no `npm install` against your `package.json`'s actual dependency
  versions, no Groq API, and no reach to your Supabase instance. Per the
  Constitution's rule 7 ("every module's test suite must pass under real
  test runs before being called complete — no assumed-passing"), these are
  **not yet verified as passing** — that has to happen in your environment.
  Please run them and paste the real output back; I'll fix anything that
  breaks against your actual setup.
- **Could not run the manual live verification** against real Module
  02 stories in your Supabase DB — same reason (no network/credentials
  here). Once the migration is applied, run:
  ```
  npx prisma migrate dev --name add_verified_claim
  ```
  then hit `POST /api/verification/run` against your dev server with real
  pending stories, and paste back a couple of the actual tiered claims it
  produces so we can sanity-check them together (per the brief's requirement
  B — this needs a human read, not a rubber stamp).
- **Nothing has been committed or pushed.** Per the Constitution's chain of
  command, that stays with you.

## Left for Module 04 (untouched, as scoped)

No ranking, scoring, or editorial-reason logic was added anywhere — Story's
`fitScore` field is untouched, and nothing in this delivery reads or writes
it.
